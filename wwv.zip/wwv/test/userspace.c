#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <stdlib.h>

#include "wwv.h"

int main(int argc, char* argv[])
{
	int ret_val;
	int fd;

	fd = open("/dev/wwv", O_WRONLY);
	if (fd < 0) {
		printf("Can't open device file");
		return -1;
	}
	
	ret_val = ioctl(fd, WWV_TRANSMIT, 1);
	if(ret_val < 0) {
		printf("ioctl failed");
		return -1;
	}

	close(fd);
}
