#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x17300f3a, "module_layout" },
	{ 0xb14db835, "platform_driver_unregister" },
	{ 0xfd052ee3, "__platform_driver_register" },
	{ 0x62686042, "device_create" },
	{ 0xe609c355, "__class_create" },
	{ 0x89daedb, "__register_chrdev" },
	{ 0x79a5327, "of_find_node_by_name" },
	{ 0x1b27718b, "_dev_err" },
	{ 0x76fad4ec, "gpio_to_desc" },
	{ 0xe8377a7d, "devm_gpio_request_one" },
	{ 0x617a224c, "of_property_read_string" },
	{ 0xdb7305a1, "__stack_chk_fail" },
	{ 0xf5f459da, "of_node_put" },
	{ 0xe17cf9a5, "of_get_named_gpio_flags" },
	{ 0x56c6f66d, "of_get_child_by_name" },
	{ 0x8f678b07, "__stack_chk_guard" },
	{ 0x9794f120, "gpiod_set_value" },
	{ 0x5f754e5a, "memset" },
	{ 0x28cc25db, "arm_copy_from_user" },
	{ 0x96de1846, "kmem_cache_alloc_trace" },
	{ 0xe04a6c96, "kmalloc_caches" },
	{ 0xef022990, "_dev_info" },
	{ 0x7c32d0f0, "printk" },
	{ 0x37a0cba, "kfree" },
	{ 0x4e8d88f2, "devm_gpio_free" },
	{ 0xb816ffef, "desc_to_gpio" },
	{ 0x6bc3fbc0, "__unregister_chrdev" },
	{ 0xa836db36, "class_destroy" },
	{ 0xe6ff264b, "device_destroy" },
	{ 0x2e5810c6, "__aeabi_unwind_cpp_pr1" },
	{ 0xb1ad28e0, "__gnu_mcount_nc" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("of:N*T*Cbrcm,bcm2835-wwv");
MODULE_ALIAS("of:N*T*Cbrcm,bcm2835-wwvC*");

MODULE_INFO(srcversion, "8AE39FEFC7ACD2BCB38C0B7");
